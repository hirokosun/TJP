import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X, BookOpen } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Navbar() {
  const { lang, setLang, t } = useLanguage();
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '/', label: t('首頁', 'Home') },
    { href: '/about', label: t('關於期刊', 'About') },
    { href: '/editorial-board', label: t('編輯委員會', 'Editorial Board') },
    { href: '/contact', label: t('聯絡我們', 'Contact') },
  ];

  const isActive = (href: string) => location === href;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-sm shadow-sm border-b border-border'
          : 'bg-white border-b border-border'
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-3 group">
              <div className="flex items-center justify-center w-9 h-9 rounded bg-primary text-primary-foreground">
                <BookOpen size={18} />
              </div>
              <div className="flex flex-col leading-tight">
                <span
                  className="text-sm font-bold text-foreground"
                  style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                >
                  {t('臺灣精神分析期刊', 'Taiwan Journal of Psychoanalysis')}
                </span>
                <span className="text-[10px] text-muted-foreground tracking-wider uppercase">
                  {t('Taiwan Journal of Psychoanalysis', '臺灣精神分析期刊')}
                </span>
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`nav-link text-sm font-medium transition-colors duration-200 ${
                    isActive(link.href)
                      ? 'text-primary active'
                      : 'text-foreground/70 hover:text-foreground'
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* Language Toggle + Mobile Menu */}
          <div className="flex items-center gap-3">
            {/* Language Toggle */}
            <div className="flex items-center border border-border rounded overflow-hidden text-xs font-medium">
              <button
                onClick={() => setLang('zh')}
                className={`px-2.5 py-1.5 transition-colors ${
                  lang === 'zh'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
              >
                中
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2.5 py-1.5 transition-colors ${
                  lang === 'en'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
              >
                EN
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-1.5 rounded hover:bg-muted transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-white">
          <nav className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  onClick={() => setMobileOpen(false)}
                  className={`block px-3 py-2.5 rounded text-sm font-medium transition-colors ${
                    isActive(link.href)
                      ? 'bg-accent text-primary'
                      : 'text-foreground/70 hover:bg-muted hover:text-foreground'
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
