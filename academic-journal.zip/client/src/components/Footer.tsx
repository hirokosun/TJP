import { BookOpen, Mail, Globe } from 'lucide-react';
import { Link } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-foreground text-white mt-20">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex items-center justify-center w-9 h-9 rounded bg-white/10 text-white">
                <BookOpen size={18} />
              </div>
              <div className="flex flex-col leading-tight">
                <span
                  className="text-sm font-bold text-white"
                  style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                >
                  {t('臺灣精神分析期刊', 'Taiwan Journal of Psychoanalysis')}
                </span>
                <span className="text-[10px] text-white/50 tracking-wider uppercase">
                  {t('Taiwan Journal of Psychoanalysis', '臺灣精神分析期刊')}
                </span>
              </div>
            </div>
            <p className="text-white/60 text-sm leading-relaxed">
              {t(
                '致力於推動精神分析學術研究，促進知識交流與學術創新。',
                'Dedicated to advancing psychoanalytic academic research and fostering scholarly exchange.'
              )}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-white/90 uppercase tracking-wider mb-4">
              {t('快速連結', 'Quick Links')}
            </h4>
            <ul className="space-y-2">
              {[
                { href: '/', zh: '首頁', en: 'Home' },
                { href: '/about', zh: '關於期刊', en: 'About Journal' },
                { href: '/editorial-board', zh: '編輯委員會', en: 'Editorial Board' },
                { href: '/contact', zh: '聯絡我們', en: 'Contact Us' },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href}>
                    <span className="text-sm text-white/60 hover:text-white transition-colors">
                      {t(link.zh, link.en)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-sm font-semibold text-white/90 uppercase tracking-wider mb-4">
              {t('聯絡資訊', 'Contact Information')}
            </h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2.5 text-sm text-white/60">
                <Mail size={14} className="shrink-0 text-white/40" />
                <span>tjp.journal@gmail.com</span>
              </li>
              <li className="flex items-center gap-2.5 text-sm text-white/60">
                <Globe size={14} className="shrink-0 text-white/40" />
                <span>ISSN:</span>
              </li>
            </ul>
            <div className="mt-5 pt-5 border-t border-white/10">
              <p className="text-xs text-white/40">
                {t('出版頻率：每年一期', 'Published annually')}
              </p>
              <p className="text-xs text-white/40 mt-1">
                {t('創刊年份：2026 年', 'Founded in 2026')}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-white/40">
            © 2026 {t('臺灣精神分析期刊', 'Taiwan Journal of Psychoanalysis')}. {t('版權所有', 'All rights reserved')}.
          </p>
          <p className="text-xs text-white/40">
            {t('同儕審查 · 開放取用', 'Peer-Reviewed · Open Access')}
          </p>
        </div>
      </div>
    </footer>
  );
}
