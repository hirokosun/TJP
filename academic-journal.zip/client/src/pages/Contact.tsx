import { useRef, useEffect } from 'react';
import { Mail, MapPin, Clock, Phone, ExternalLink } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-6');
        }
      });
    }, { threshold: 0.1 });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={`opacity-0 translate-y-6 transition-all duration-700 ease-out ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export default function Contact() {
  const { t } = useLanguage();

  const contactItems = [
    {
      icon: <Mail size={20} className="text-primary" />,
      label: t('電子郵件', 'Email'),
      value: 'editor@jar-journal.org',
      sub: t('一般查詢', 'General Inquiries'),
      href: 'mailto:editor@jar-journal.org',
    },
    {
      icon: <Mail size={20} className="text-primary" />,
      label: t('投稿信箱', 'Submission Email'),
      value: 'submit@jar-journal.org',
      sub: t('稿件投遞', 'Manuscript Submission'),
      href: 'mailto:submit@jar-journal.org',
    },
    {
      icon: <Phone size={20} className="text-primary" />,
      label: t('電話', 'Phone'),
      value: '+886-2-1234-5678',
      sub: t('週一至週五 09:00–17:00', 'Mon–Fri 09:00–17:00'),
    },
    {
      icon: <MapPin size={20} className="text-primary" />,
      label: t('地址', 'Address'),
      value: t('台北市大安區羅斯福路四段1號', '1 Roosevelt Rd., Sec. 4, Da\'an Dist., Taipei'),
      sub: t('臺灣精神分析學會', 'Taiwan Psychoanalytic Society'),
    },
    {
      icon: <Clock size={20} className="text-primary" />,
      label: t('辦公時間', 'Office Hours'),
      value: t('週一至週五', 'Monday to Friday'),
      sub: '09:00 – 17:00 (GMT+8)',
    },
  ];

  const faqItems = [
    {
      q: t('如何投稿？', 'How do I submit a manuscript?'),
      a: t(
        '請將稿件以 Word 或 PDF 格式寄送至 submit@jar-journal.org，並附上作者資訊及摘要。我們將在5個工作天內回覆收稿確認。',
        'Please send your manuscript in Word or PDF format to submit@jar-journal.org, along with author information and abstract. We will reply with a submission confirmation within 5 business days.'
      ),
    },
    {
      q: t('審查時間需要多久？', 'How long does the review process take?'),
      a: t(
        '初審通常需要1–2週，同儕審查程序約需4–8週。整體流程從投稿到最終決定約需2–4個月。',
        'Initial review typically takes 1–2 weeks, and the peer review process takes approximately 4–8 weeks. The overall process from submission to final decision takes about 2–4 months.'
      ),
    },
    {
      q: t('是否收取投稿費用？', 'Are there any submission fees?'),
      a: t(
        '本期刊採開放取用政策，不收取讀者閱讀費用。投稿本身免費，但接受後需支付文章處理費（APC）以維持開放取用服務。',
        'Our journal follows an open-access policy and does not charge readers. Submission is free, but upon acceptance, an Article Processing Charge (APC) is required to maintain the open-access service.'
      ),
    },
    {
      q: t('可以投稿英文以外的語言嗎？', 'Can I submit in languages other than English?'),
      a: t(
        '本期刊接受中文及英文稿件。中文稿件需附上英文摘要及關鍵詞；英文稿件則需附上中文摘要（若作者能力許可）。',
        'Our journal accepts manuscripts in both Chinese and English. Chinese manuscripts must include an English abstract and keywords; English manuscripts should include a Chinese abstract if the author is able.'
      ),
    },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Page Header */}
      <section className="py-16 bg-accent/30 border-b border-border">
        <div className="container">
          <AnimatedSection>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <span>{t('首頁', 'Home')}</span>
              <span>/</span>
              <span className="text-primary">{t('聯絡我們', 'Contact Us')}</span>
            </div>
            <h1
              className="section-heading text-3xl md:text-4xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('聯絡我們', 'Contact Us')}
            </h1>
            <p className="text-muted-foreground ml-4 max-w-2xl">
              {t(
                '如有任何問題或查詢，歡迎透過以下方式與我們聯繫。我們的編輯團隊將盡快回覆您的訊息。',
                'If you have any questions or inquiries, please feel free to contact us through the following channels. Our editorial team will respond to your message as soon as possible.'
              )}
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left: Contact Details */}
            <div>
              <AnimatedSection>
                <h2
                  className="section-heading text-2xl font-bold text-foreground mb-8"
                  style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                >
                  {t('聯絡資訊', 'Contact Information')}
                </h2>
              </AnimatedSection>

              <div className="space-y-4">
                {contactItems.map((item, i) => (
                  <AnimatedSection key={i} delay={i * 80}>
                    <div className="flex gap-4 p-5 bg-white border border-border rounded-lg hover:border-primary/30 hover:shadow-sm transition-all duration-250">
                      <div className="w-10 h-10 rounded bg-accent flex items-center justify-center shrink-0">
                        {item.icon}
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-0.5 font-medium uppercase tracking-wide">
                          {item.label}
                        </div>
                        {item.href ? (
                          <a
                            href={item.href}
                            className="text-sm font-medium text-primary hover:underline flex items-center gap-1"
                          >
                            {item.value}
                            <ExternalLink size={12} />
                          </a>
                        ) : (
                          <div className="text-sm font-medium text-foreground">{item.value}</div>
                        )}
                        <div className="text-xs text-muted-foreground mt-0.5">{item.sub}</div>
                      </div>
                    </div>
                  </AnimatedSection>
                ))}
              </div>
            </div>

            {/* Right: FAQ */}
            <div>
              <AnimatedSection>
                <h2
                  className="section-heading text-2xl font-bold text-foreground mb-8"
                  style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                >
                  {t('常見問題', 'Frequently Asked Questions')}
                </h2>
              </AnimatedSection>

              <div className="space-y-4">
                {faqItems.map((item, i) => (
                  <AnimatedSection key={i} delay={i * 100}>
                    <div className="border border-border rounded-lg overflow-hidden">
                      <div className="px-5 py-4 bg-accent/30 border-b border-border">
                        <h3
                          className="text-sm font-bold text-foreground"
                          style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                        >
                          {item.q}
                        </h3>
                      </div>
                      <div className="px-5 py-4 bg-white">
                        <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                      </div>
                    </div>
                  </AnimatedSection>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Submission Guidelines CTA */}
      <section className="py-16 bg-primary">
        <div className="container">
          <AnimatedSection>
            <div className="max-w-2xl mx-auto text-center">
              <h2
                className="text-2xl font-bold text-white mb-4"
                style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
              >
                {t('準備好投稿了嗎？', 'Ready to Submit?')}
              </h2>
              <p className="text-white/70 mb-8 leading-relaxed">
                {t(
                  '在投稿前，請詳細閱讀本期刊的投稿指南，以確保您的稿件符合格式與內容要求。',
                  'Before submitting, please carefully read our submission guidelines to ensure your manuscript meets the formatting and content requirements.'
                )}
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <a
                  href="mailto:submit@jar-journal.org"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white text-primary text-sm font-medium rounded hover:bg-white/90 transition-colors"
                >
                  <Mail size={16} />
                  {t('立即投稿', 'Submit Now')}
                </a>
                <a
                  href="mailto:editor@jar-journal.org"
                  className="inline-flex items-center gap-2 px-6 py-3 border border-white/40 text-white text-sm font-medium rounded hover:bg-white/10 transition-colors"
                >
                  {t('聯絡編輯', 'Contact Editor')}
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
