import { useRef, useEffect } from 'react';
import { BookOpen, Target, Eye, FileText, CheckCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-6');
        }
      });
    }, { threshold: 0.1 });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={`opacity-0 translate-y-6 transition-all duration-700 ease-out ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export default function About() {
  const { t } = useLanguage();

  const scope = [
    t('人文與社會科學', 'Humanities and Social Sciences'),
    t('自然科學與工程', 'Natural Sciences and Engineering'),
    t('醫學與生命科學', 'Medicine and Life Sciences'),
    t('教育與心理學', 'Education and Psychology'),
    t('法律與政策研究', 'Law and Policy Studies'),
    t('環境與永續發展', 'Environment and Sustainable Development'),
    t('跨領域整合研究', 'Interdisciplinary Integrative Research'),
    t('藝術與文化研究', 'Arts and Cultural Studies'),
  ];

  const submissionTypes = [
    {
      type: t('原創研究論文', 'Original Research Articles'),
      desc: t('呈現新穎研究發現的完整學術論文，字數約6,000–10,000字。', 'Full academic papers presenting novel research findings, approximately 6,000–10,000 words.'),
    },
    {
      type: t('綜述文章', 'Review Articles'),
      desc: t('對特定研究領域進行系統性回顧與分析，字數約8,000–15,000字。', 'Systematic reviews and analyses of specific research areas, approximately 8,000–15,000 words.'),
    },
    {
      type: t('研究簡報', 'Research Notes'),
      desc: t('呈現初步研究結果或方法論創新的短篇報告，字數約2,000–4,000字。', 'Short reports presenting preliminary findings or methodological innovations, approximately 2,000–4,000 words.'),
    },
    {
      type: t('書評', 'Book Reviews'),
      desc: t('對近期重要學術著作的評論與分析，字數約1,000–2,000字。', 'Critical reviews and analyses of recent significant academic works, approximately 1,000–2,000 words.'),
    },
  ];

  const timeline = [
    { step: '01', label: t('投稿', 'Submission'), desc: t('透過線上系統提交稿件', 'Submit manuscript via online system') },
    { step: '02', label: t('初審', 'Initial Review'), desc: t('編輯委員會進行格式與範圍審查（1–2週）', 'Editorial board reviews format and scope (1–2 weeks)') },
    { step: '03', label: t('同儕審查', 'Peer Review'), desc: t('雙盲同儕審查程序（4–8週）', 'Double-blind peer review process (4–8 weeks)') },
    { step: '04', label: t('修訂', 'Revision'), desc: t('作者依審查意見修訂稿件', 'Author revises manuscript based on reviewer comments') },
    { step: '05', label: t('接受', 'Acceptance'), desc: t('最終決定與接受通知', 'Final decision and acceptance notification') },
    { step: '06', label: t('出版', 'Publication'), desc: t('線上優先出版及期刊收錄', 'Online first publication and journal inclusion') },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Page Header */}
      <section className="py-16 bg-accent/30 border-b border-border">
        <div className="container">
          <AnimatedSection>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <span>{t('首頁', 'Home')}</span>
              <span>/</span>
              <span className="text-primary">{t('關於期刊', 'About the Journal')}</span>
            </div>
            <h1
              className="section-heading text-3xl md:text-4xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('關於期刊', 'About the Journal')}
            </h1>
            <p className="text-muted-foreground ml-4 max-w-2xl">
              {t(
                '臺灣精神分析期刊（Taiwan Journal of Psychoanalysis）自2026年創刊以來，致力於成為推動精神分析學術交流的重要平台。',
                'The Taiwan Journal of Psychoanalysis, founded in 2026, is dedicated to serving as a vital platform for psychoanalytic academic exchange.'
              )}
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <AnimatedSection delay={0}>
              <div className="card-accent border border-border rounded-lg p-8 h-full">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded bg-accent flex items-center justify-center">
                    <Target size={20} className="text-primary" />
                  </div>
                  <h2
                    className="text-xl font-bold text-foreground"
                    style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                  >
                    {t('使命', 'Mission')}
                  </h2>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {t(
                    '本期刊的使命在於提供一個嚴謹、開放且具包容性的學術發表平台，鼓勵來自世界各地的研究者分享其創新研究成果，促進知識的自由流通與學術社群的持續發展。我們相信，高品質的學術出版是推動人類知識進步的核心動力。',
                    "Our mission is to provide a rigorous, open, and inclusive academic publishing platform that encourages researchers from around the world to share their innovative findings, promoting the free flow of knowledge and the continuous development of the academic community. We believe that high-quality academic publishing is the core driver of human knowledge advancement."
                  )}
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection delay={150}>
              <div className="card-accent border border-border rounded-lg p-8 h-full">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded bg-accent flex items-center justify-center">
                    <Eye size={20} className="text-primary" />
                  </div>
                  <h2
                    className="text-xl font-bold text-foreground"
                    style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                  >
                    {t('願景', 'Vision')}
                  </h2>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {t(
                    '我們的願景是成為亞太地區最具影響力的跨領域學術期刊之一，連結東西方學術社群，打破語言與地域的藩籬，讓優質研究能夠觸及更廣泛的讀者群，並在全球學術對話中佔有重要地位。',
                    'Our vision is to become one of the most influential interdisciplinary academic journals in the Asia-Pacific region, connecting Eastern and Western academic communities, breaking down linguistic and geographic barriers, and enabling quality research to reach a broader audience while playing an important role in global academic dialogue.'
                  )}
                </p>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Journal Info */}
      <section className="py-16 bg-secondary/20">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-10"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('期刊基本資訊', 'Journal Information')}
            </h2>
          </AnimatedSection>

          <AnimatedSection delay={100}>
            <div className="bg-white border border-border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {[
                    [t('期刊名稱（中文）', 'Journal Name (Chinese)'), '臺灣精神分析期刊'],
                    [t('期刊名稱（英文）', 'Journal Name (English)'), 'Taiwan Journal of Psychoanalysis'],
                    ['ISSN (Print)', ''],
                    ['ISSN (Online)', ''],
                    [t('出版頻率', 'Publication Frequency'), t('每年一期', 'Annual')],
                    [t('創刊年份', 'Founded'), '2026'],
                    [t('出版語言', 'Publication Language'), t('中文、英文', 'Chinese, English')],
                    [t('審查方式', 'Review Process'), t('雙盲同儕審查', 'Double-blind Peer Review')],
                    [t('取用方式', 'Access Type'), t('開放取用（Open Access）', 'Open Access')],
                    [t('主辦機構', 'Publisher'), t('學術研究出版協會', 'Academic Research Publishing Association')],
                  ].map(([key, val], i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-muted/30'}>
                      <td className="px-6 py-3.5 font-medium text-foreground w-1/3 border-r border-border">{key}</td>
                      <td className="px-6 py-3.5 text-muted-foreground">{val}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Scope */}
      <section className="py-16 bg-white">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('收稿範圍', 'Scope of Coverage')}
            </h2>
            <p className="text-muted-foreground ml-4 mb-10">
              {t('本期刊歡迎以下領域的高品質學術研究投稿：', 'We welcome high-quality academic research submissions in the following areas:')}
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {scope.map((item, i) => (
              <AnimatedSection key={i} delay={i * 60}>
                <div className="flex items-center gap-3 p-4 bg-accent/40 rounded-lg border border-border/50">
                  <CheckCircle size={16} className="text-primary shrink-0" />
                  <span className="text-sm font-medium text-foreground">{item}</span>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Submission Types */}
      <section className="py-16 bg-secondary/20">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-10"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('稿件類型', 'Manuscript Types')}
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {submissionTypes.map((item, i) => (
              <AnimatedSection key={i} delay={i * 100}>
                <div className="bg-white border border-border rounded-lg p-6 flex gap-4 hover:-translate-y-1 hover:shadow-md transition-all duration-250">
                  <div className="w-10 h-10 rounded bg-accent flex items-center justify-center shrink-0 mt-0.5">
                    <FileText size={18} className="text-primary" />
                  </div>
                  <div>
                    <h3
                      className="font-bold text-foreground mb-1.5"
                      style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                    >
                      {item.type}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Review Process Timeline */}
      <section className="py-16 bg-white">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-10"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('審查流程', 'Review Process')}
            </h2>
          </AnimatedSection>

          <div className="relative">
            {/* Connecting line */}
            <div className="hidden md:block absolute top-8 left-0 right-0 h-0.5 bg-border z-0" style={{ left: '4rem', right: '4rem' }} />

            <div className="grid grid-cols-2 md:grid-cols-6 gap-6 relative z-10">
              {timeline.map((item, i) => (
                <AnimatedSection key={i} delay={i * 80}>
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex flex-col items-center justify-center mb-3 shadow-sm">
                      <span className="text-xs font-bold opacity-70">{item.step}</span>
                      <BookOpen size={16} />
                    </div>
                    <h4
                      className="text-sm font-bold text-foreground mb-1"
                      style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                    >
                      {item.label}
                    </h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
