import { useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { ArrowRight, BookOpen, Users, Globe, Award, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const HERO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663506814903/fo9hgsxLCeTCDL9UcbH5BU/hero-abstract-DVLQi3BZzPDq3eH4XZkYK6.webp';

function useIntersectionObserver(ref: React.RefObject<Element | null>, options?: IntersectionObserverInit) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-6');
        }
      });
    }, { threshold: 0.1, ...options });
    observer.observe(el);
    return () => observer.disconnect();
  }, [ref]);
}

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useIntersectionObserver(ref as React.RefObject<Element>);
  return (
    <div
      ref={ref}
      className={`opacity-0 translate-y-6 transition-all duration-700 ease-out ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export default function Home() {
  const { t, lang } = useLanguage();

  const features = [
    {
      icon: <BookOpen size={22} className="text-primary" />,
      title: t('嚴格同儕審查', 'Rigorous Peer Review'),
      desc: t(
        '所有投稿均經過雙盲同儕審查程序，確保學術品質與研究誠信。',
        'All submissions undergo double-blind peer review to ensure academic quality and research integrity.'
      ),
    },
    {
      icon: <Globe size={22} className="text-primary" />,
      title: t('開放取用', 'Open Access'),
      desc: t(
        '本期刊採開放取用政策，所有已發表文章均可免費線上閱讀。',
        'Our journal follows an open-access policy, making all published articles freely available online.'
      ),
    },
    {
      icon: <Users size={22} className="text-primary" />,
      title: t('跨領域研究', 'Interdisciplinary Research'),
      desc: t(
        '歡迎來自人文、社會、自然科學等多元領域的高品質學術研究。',
        'We welcome high-quality research from humanities, social sciences, natural sciences, and beyond.'
      ),
    },
    {
      icon: <Award size={22} className="text-primary" />,
      title: t('國際索引', 'International Indexing'),
      desc: t(
        '本期刊已收錄於多個主要學術資料庫，提升研究的國際能見度。',
        'Indexed in major academic databases, enhancing the international visibility of published research.'
      ),
    },
  ];

  const announcements = [
    {
      date: '2024-03',
      tag: t('公告', 'Announcement'),
      title: t('第14卷第1期現已上線', 'Volume 14, Issue 1 Now Available'),
      desc: t('本期收錄12篇精選論文，涵蓋跨領域研究成果。', 'This issue features 12 selected papers covering interdisciplinary research findings.'),
    },
    {
      date: '2024-02',
      tag: t('徵稿', 'Call for Papers'),
      title: t('第14卷第2期徵稿中', 'Call for Papers: Volume 14, Issue 2'),
      desc: t('截止日期：2024年5月31日。歡迎各領域學者投稿。', 'Submission deadline: May 31, 2024. Scholars from all disciplines are welcome.'),
    },
    {
      date: '2024-01',
      tag: t('獎項', 'Award'),
      title: t('榮獲年度最佳期刊獎', 'Awarded Best Journal of the Year'),
      desc: t('本期刊榮獲國際學術出版協會年度最佳期刊殊榮。', 'Our journal received the Best Journal of the Year award from the International Academic Publishing Association.'),
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-16 min-h-[90vh] flex items-center relative overflow-hidden bg-white">
        {/* Background subtle pattern */}
        <div
          className="absolute inset-0 opacity-30 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_IMG})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 to-white/40" />

        <div className="container relative z-10">
          <div className="max-w-2xl">


            <h1
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6 animate-fade-in-up animate-delay-100"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {lang === 'zh' ? (
                <>臺灣精神分析期刊<br /><span className="text-primary">Taiwan Journal of</span><br />Psychoanalysis</>
              ) : (
                <><span className="text-primary">Taiwan Journal of</span><br />Psychoanalysis<br />臺灣精神分析期刊</>
              )}
            </h1>

            <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl animate-fade-in-up animate-delay-200">
              {t(
                '致力於發表跨領域高品質學術研究，促進全球學者之間的知識交流與學術創新，推動人類知識的前沿發展。',
                'Committed to publishing high-quality interdisciplinary research, fostering knowledge exchange among global scholars, and advancing the frontiers of human knowledge.'
              )}
            </p>

            <div className="flex flex-wrap gap-3 animate-fade-in-up animate-delay-300">
              <Link href="/about">
                <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded hover:bg-primary/90 transition-colors">
                  {t('了解更多', 'Learn More')}
                  <ArrowRight size={16} />
                </span>
              </Link>
              <Link href="/editorial-board">
                <span className="inline-flex items-center gap-2 px-5 py-2.5 border border-border text-foreground text-sm font-medium rounded hover:bg-muted transition-colors">
                  {t('編輯委員會', 'Editorial Board')}
                  <ChevronRight size={16} />
                </span>
              </Link>
            </div>
          </div>
        </div>
      </section>



      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container">
          <AnimatedSection>
            <div className="mb-12">
              <h2
                className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-3"
                style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
              >
                {t('期刊特色', 'Journal Features')}
              </h2>
              <p className="text-muted-foreground text-sm ml-4">
                {t('我們的核心承諾與學術標準', 'Our core commitments and academic standards')}
              </p>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <AnimatedSection key={i} delay={i * 100}>
                <div className="card-accent bg-white border border-border rounded-lg p-6 hover:-translate-y-1 hover:shadow-md transition-all duration-250 h-full">
                  <div className="w-10 h-10 rounded bg-accent flex items-center justify-center mb-4">
                    {f.icon}
                  </div>
                  <h3
                    className="text-base font-bold text-foreground mb-2"
                    style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                  >
                    {f.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Announcements */}
      <section className="py-20 bg-secondary/30">
        <div className="container">
          <AnimatedSection>
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2
                  className="section-heading text-2xl md:text-3xl font-bold text-foreground mb-3"
                  style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                >
                  {t('最新消息', 'Latest News')}
                </h2>
                <p className="text-muted-foreground text-sm ml-4">
                  {t('期刊公告與重要通知', 'Journal announcements and important notices')}
                </p>
              </div>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {announcements.map((item, i) => (
              <AnimatedSection key={i} delay={i * 120}>
                <div className="bg-white border border-border rounded-lg p-6 hover:-translate-y-1 hover:shadow-md transition-all duration-250 h-full flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <span className="inline-block px-2.5 py-1 bg-accent text-primary text-xs font-medium rounded">
                      {item.tag}
                    </span>
                    <span className="text-xs text-muted-foreground">{item.date}</span>
                  </div>
                  <h3
                    className="text-base font-bold text-foreground mb-2 flex-1"
                    style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
                  >
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-white">
        <div className="container">
          <AnimatedSection>
            <div className="max-w-2xl mx-auto text-center">
              <h2
                className="text-2xl md:text-3xl font-bold text-foreground mb-4"
                style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
              >
                {t('加入我們的學術社群', 'Join Our Academic Community')}
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                {t(
                  '無論您是研究者、學者或學生，我們歡迎您探索本期刊的豐富學術資源，並考慮投稿分享您的研究成果。',
                  'Whether you are a researcher, scholar, or student, we invite you to explore our rich academic resources and consider submitting your research.'
                )}
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <Link href="/about">
                  <span className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-sm font-medium rounded hover:bg-primary/90 transition-colors">
                    {t('了解期刊', 'About the Journal')}
                    <ArrowRight size={16} />
                  </span>
                </Link>
                <Link href="/contact">
                  <span className="inline-flex items-center gap-2 px-6 py-3 border border-border text-foreground text-sm font-medium rounded hover:bg-muted transition-colors">
                    {t('聯絡我們', 'Contact Us')}
                  </span>
                </Link>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
