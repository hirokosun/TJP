import { useRef, useEffect } from 'react';
import { Mail, Globe, GraduationCap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const BG_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663506814903/fo9hgsxLCeTCDL9UcbH5BU/editorial-board-bg-a6boUFpCUpmcd2YmzvGGjr.webp';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-6');
        }
      });
    }, { threshold: 0.1 });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={`opacity-0 translate-y-6 transition-all duration-700 ease-out ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

interface Member {
  nameZh: string;
  nameEn: string;
  titleZh: string;
  titleEn: string;
  affZh: string;
  affEn: string;
  specialtyZh: string[];
  specialtyEn: string[];
  email?: string;
  initials: string;
  color: string;
}

const editorInChief: Member = {
  nameZh: '陳志明 教授',
  nameEn: 'Prof. Chen Chih-Ming',
  titleZh: '主編',
  titleEn: 'Editor-in-Chief',
  affZh: '國立台灣大學社會科學院',
  affEn: 'College of Social Sciences, National Taiwan University',
  specialtyZh: ['社會學', '質性研究方法', '東亞比較研究'],
  specialtyEn: ['Sociology', 'Qualitative Research Methods', 'East Asian Comparative Studies'],
  email: 'c.chen@jar-journal.org',
  initials: 'CC',
  color: 'bg-primary',
};

const associateEditors: Member[] = [
  {
    nameZh: '林美華 副教授',
    nameEn: 'Assoc. Prof. Lin Mei-Hua',
    titleZh: '副主編',
    titleEn: 'Associate Editor',
    affZh: '國立政治大學文學院',
    affEn: 'College of Liberal Arts, National Chengchi University',
    specialtyZh: ['比較文學', '文化研究', '後殖民理論'],
    specialtyEn: ['Comparative Literature', 'Cultural Studies', 'Postcolonial Theory'],
    initials: 'LM',
    color: 'bg-blue-600',
  },
  {
    nameZh: '王建國 教授',
    nameEn: 'Prof. Wang Chien-Kuo',
    titleZh: '副主編',
    titleEn: 'Associate Editor',
    affZh: '清華大學理學院',
    affEn: 'College of Science, National Tsing Hua University',
    specialtyZh: ['科學哲學', '知識論', '科技與社會'],
    specialtyEn: ['Philosophy of Science', 'Epistemology', 'Science and Technology Studies'],
    initials: 'WC',
    color: 'bg-slate-600',
  },
];

const boardMembers: Member[] = [
  {
    nameZh: '張雅婷 教授',
    nameEn: 'Prof. Chang Ya-Ting',
    titleZh: '編輯委員',
    titleEn: 'Editorial Board Member',
    affZh: '成功大學醫學院',
    affEn: 'College of Medicine, National Cheng Kung University',
    specialtyZh: ['公共衛生', '流行病學', '健康政策'],
    specialtyEn: ['Public Health', 'Epidemiology', 'Health Policy'],
    initials: 'CY',
    color: 'bg-blue-500',
  },
  {
    nameZh: '李俊賢 副教授',
    nameEn: 'Assoc. Prof. Li Chun-Hsien',
    titleZh: '編輯委員',
    titleEn: 'Editorial Board Member',
    affZh: '中央研究院社會學研究所',
    affEn: 'Institute of Sociology, Academia Sinica',
    specialtyZh: ['政治社會學', '民主化研究', '選舉研究'],
    specialtyEn: ['Political Sociology', 'Democratization Studies', 'Electoral Research'],
    initials: 'LC',
    color: 'bg-indigo-600',
  },
  {
    nameZh: 'Dr. Sarah Johnson',
    nameEn: 'Dr. Sarah Johnson',
    titleZh: '國際編輯委員',
    titleEn: 'International Editorial Board Member',
    affZh: '哈佛大學東亞研究系',
    affEn: 'Department of East Asian Studies, Harvard University',
    specialtyZh: ['東亞政治', '比較政治學', '國際關係'],
    specialtyEn: ['East Asian Politics', 'Comparative Politics', 'International Relations'],
    initials: 'SJ',
    color: 'bg-sky-600',
  },
  {
    nameZh: 'Prof. Michael Chen',
    nameEn: 'Prof. Michael Chen',
    titleZh: '國際編輯委員',
    titleEn: 'International Editorial Board Member',
    affZh: '新加坡國立大學社會學系',
    affEn: 'Department of Sociology, National University of Singapore',
    specialtyZh: ['移民研究', '城市社會學', '東南亞研究'],
    specialtyEn: ['Migration Studies', 'Urban Sociology', 'Southeast Asian Studies'],
    initials: 'MC',
    color: 'bg-teal-600',
  },
  {
    nameZh: '吳淑芬 教授',
    nameEn: 'Prof. Wu Shu-Fen',
    titleZh: '編輯委員',
    titleEn: 'Editorial Board Member',
    affZh: '台灣師範大學教育學院',
    affEn: 'College of Education, National Taiwan Normal University',
    specialtyZh: ['教育政策', '課程研究', '比較教育'],
    specialtyEn: ['Education Policy', 'Curriculum Studies', 'Comparative Education'],
    initials: 'WS',
    color: 'bg-violet-600',
  },
  {
    nameZh: '黃文哲 副教授',
    nameEn: 'Assoc. Prof. Huang Wen-Che',
    titleZh: '編輯委員',
    titleEn: 'Editorial Board Member',
    affZh: '中興大學法律學院',
    affEn: 'College of Law, National Chung Hsing University',
    specialtyZh: ['憲法學', '行政法', '人權法'],
    specialtyEn: ['Constitutional Law', 'Administrative Law', 'Human Rights Law'],
    initials: 'HW',
    color: 'bg-blue-700',
  },
];

function MemberCard({ member, large = false }: { member: Member; large?: boolean }) {
  const { t, lang } = useLanguage();
  const name = lang === 'zh' ? member.nameZh : member.nameEn;
  const title = lang === 'zh' ? member.titleZh : member.titleEn;
  const aff = lang === 'zh' ? member.affZh : member.affEn;
  const specialty = lang === 'zh' ? member.specialtyZh : member.specialtyEn;

  if (large) {
    return (
      <div className="card-accent bg-white border border-border rounded-lg p-8 flex flex-col md:flex-row gap-6 hover:shadow-md transition-all duration-250">
        <div className={`w-20 h-20 rounded-full ${member.color} text-white flex items-center justify-center text-2xl font-bold shrink-0`}
          style={{ fontFamily: "'Merriweather', serif" }}>
          {member.initials}
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
            <div>
              <h3
                className="text-xl font-bold text-foreground"
                style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
              >
                {name}
              </h3>
              <span className="inline-block mt-1 px-2.5 py-0.5 bg-primary text-primary-foreground text-xs font-medium rounded">
                {title}
              </span>
            </div>
            {member.email && (
              <a
                href={`mailto:${member.email}`}
                className="flex items-center gap-1.5 text-xs text-primary hover:underline"
              >
                <Mail size={13} />
                {member.email}
              </a>
            )}
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <GraduationCap size={15} className="text-primary/60 shrink-0" />
            <span>{aff}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {specialty.map((s, i) => (
              <span key={i} className="px-2.5 py-1 bg-accent text-primary text-xs rounded-full">
                {s}
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card-accent bg-white border border-border rounded-lg p-5 hover:-translate-y-1 hover:shadow-md transition-all duration-250 h-full flex flex-col">
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-12 h-12 rounded-full ${member.color} text-white flex items-center justify-center text-sm font-bold shrink-0`}
          style={{ fontFamily: "'Merriweather', serif" }}>
          {member.initials}
        </div>
        <div>
          <h3
            className="text-sm font-bold text-foreground leading-tight"
            style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
          >
            {name}
          </h3>
          <span className="text-xs text-primary font-medium">{title}</span>
        </div>
      </div>
      <div className="flex items-start gap-1.5 text-xs text-muted-foreground mb-3">
        <Globe size={12} className="text-primary/60 shrink-0 mt-0.5" />
        <span className="leading-relaxed">{aff}</span>
      </div>
      <div className="flex flex-wrap gap-1.5 mt-auto">
        {specialty.map((s, i) => (
          <span key={i} className="px-2 py-0.5 bg-accent text-primary text-xs rounded-full">
            {s}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function EditorialBoard() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen pt-16">
      {/* Page Header */}
      <section
        className="py-16 relative border-b border-border overflow-hidden"
        style={{ backgroundColor: '#f0f5ff' }}
      >
        <div
          className="absolute inset-0 opacity-20 bg-cover bg-center"
          style={{ backgroundImage: `url(${BG_IMG})` }}
        />
        <div className="container relative z-10">
          <AnimatedSection>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <span>{t('首頁', 'Home')}</span>
              <span>/</span>
              <span className="text-primary">{t('編輯委員會', 'Editorial Board')}</span>
            </div>
            <h1
              className="section-heading text-3xl md:text-4xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('編輯委員會', 'Editorial Board')}
            </h1>
            <p className="text-muted-foreground ml-4 max-w-2xl">
              {t(
                '本期刊的編輯委員會由來自全球各地的傑出學者組成，他們在各自的研究領域具有卓越的學術成就與豐富的出版經驗。',
                'Our editorial board consists of distinguished scholars from around the world, each with outstanding academic achievements and extensive publishing experience in their respective fields.'
              )}
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Editor-in-Chief */}
      <section className="py-16 bg-white">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl font-bold text-foreground mb-8"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('主編', 'Editor-in-Chief')}
            </h2>
          </AnimatedSection>
          <AnimatedSection delay={100}>
            <MemberCard member={editorInChief} large />
          </AnimatedSection>
        </div>
      </section>

      {/* Associate Editors */}
      <section className="py-16 bg-secondary/20">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl font-bold text-foreground mb-8"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('副主編', 'Associate Editors')}
            </h2>
          </AnimatedSection>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {associateEditors.map((member, i) => (
              <AnimatedSection key={i} delay={i * 120}>
                <MemberCard member={member} large />
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Board Members */}
      <section className="py-16 bg-white">
        <div className="container">
          <AnimatedSection>
            <h2
              className="section-heading text-2xl font-bold text-foreground mb-8"
              style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
            >
              {t('編輯委員', 'Editorial Board Members')}
            </h2>
          </AnimatedSection>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {boardMembers.map((member, i) => (
              <AnimatedSection key={i} delay={i * 80}>
                <MemberCard member={member} />
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Join Us */}
      <section className="py-16 bg-accent/30">
        <div className="container">
          <AnimatedSection>
            <div className="max-w-2xl mx-auto text-center">
              <h2
                className="text-2xl font-bold text-foreground mb-4"
                style={{ fontFamily: "'Merriweather', 'Noto Serif TC', serif" }}
              >
                {t('有意加入編輯委員會？', 'Interested in Joining the Editorial Board?')}
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {t(
                  '我們歡迎在相關領域具有卓越學術成就的學者加入本期刊的編輯委員會。如有意願，請透過電子郵件與我們聯繫。',
                  'We welcome scholars with outstanding academic achievements in relevant fields to join our editorial board. If interested, please contact us via email.'
                )}
              </p>
              <a
                href="mailto:editor@jar-journal.org"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-sm font-medium rounded hover:bg-primary/90 transition-colors"
              >
                <Mail size={16} />
                {t('聯絡主編', 'Contact the Editor')}
              </a>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
